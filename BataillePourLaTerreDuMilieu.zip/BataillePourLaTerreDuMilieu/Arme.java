
public class Arme {
    String type;
    int degat;  
}
